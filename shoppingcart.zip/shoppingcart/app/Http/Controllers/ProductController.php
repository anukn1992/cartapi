<?php

namespace App\Http\Controllers;

use App\Models\Products;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        $perPage = $request->input('per_page', 5);
        $sortField = $request->input('sort_by', 'id');
        $categoryFilter = $request->input('category');

        $query = Products::query();

        if ($categoryFilter) {
            $query->where('category', $categoryFilter);
        }

        $query->orderBy($sortField);

        $products = $query->paginate($perPage);

        return response()->json($products);
    }
}

