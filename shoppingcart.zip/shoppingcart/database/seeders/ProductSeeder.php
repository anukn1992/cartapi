<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Products;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
       Products::truncate();
        $products =
        [
            [
                'name' => 'p1',
                'price' => '100',
                'quantity' => '10',
            ],
            [
                'name' => 'p2',
                'price' => '200',
                'quantity' => '20',
            ],
            [
                'name' => 'p3',
                'price' => '300',
                'quantity' => '30',
            ],
            [
                'name' => 'p4',
                'price' => '400',
                'quantity' => '40',
            ],
            [
                'name' => 'p5',
                'price' => '500',
                'quantity' => '50',
            ],
            [
                'name' => 'p6',
                'price' => '600',
                'quantity' => '60',
            ],
            [
                'name' => 'p7',
                'price' => '700',
                'quantity' => '70',
            ],
        ];
        Products::insert($products);
    }

}
